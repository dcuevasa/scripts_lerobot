lerobot-teleoperate \
  --robot.type=so101_mujoco \
  --teleop.type=so101_ik \
  --display_data=true